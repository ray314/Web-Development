<?php
    // Variables for connecting to mysql
    $servername = "16946889.cmslamp14.aut.ac.nz";
    $username = "fbb3628";
    $password = "sh6ch7R5";
    $dbname = "fbb3628";

?>